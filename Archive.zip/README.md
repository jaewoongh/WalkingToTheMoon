Walking to the Moon
===================
*~ The Game Part ~*

Overview
--------
This is the game part of Walking to the Moon.  
Nothing here is meaningful now, so just consider this repository as a private one.

Thanks.

Legal
-----
Copyrighted and no public license is granted at this point